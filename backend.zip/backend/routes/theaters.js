const express = require('express');
const router = express.Router();
const Theater = require('../models/Theater');
const Show = require('../models/Show');

// GET /api/theaters - Get all theaters
router.get('/', async (req, res) => {
  try {
    const { city, search } = req.query;
    let query = { isActive: true };
    
    if (city) {
      query['location.city'] = new RegExp(city, 'i');
    }
    
    if (search) {
      query.name = new RegExp(search, 'i');
    }
    
    const theaters = await Theater.find(query).sort({ name: 1 });
    res.json(theaters);
  } catch (error) {
    console.error('Error fetching theaters:', error);
    res.status(500).json({ 
      message: 'Error fetching theaters', 
      error: error.message 
    });
  }
});

// GET /api/theaters/:id - Get specific theater
router.get('/:id', async (req, res) => {
  try {
    const theater = await Theater.findById(req.params.id);
    if (!theater) {
      return res.status(404).json({ message: 'Theater not found' });
    }
    res.json(theater);
  } catch (error) {
    console.error('Error fetching theater:', error);
    res.status(500).json({ 
      message: 'Error fetching theater', 
      error: error.message 
    });
  }
});

// GET /api/theaters/:id/shows - Get shows for a specific theater
router.get('/:theaterId/shows', async (req, res) => {
  try {
    const { theaterId } = req.params;
    const { date } = req.query;
    
    let query = {
      'theaters.theater': theaterId,
      isActive: true
    };
    
    const shows = await Show.find(query)
      .populate('theaters.theater', 'name location')
      .sort({ title: 1 });
    
    // Filter to only include showtimes for the specified theater
    const filteredShows = shows.map(show => {
      const theaterData = show.theaters.find(
        t => t.theater._id.toString() === theaterId
      );
      return {
        ...show.toObject(),
        theaters: theaterData ? [theaterData] : []
      };
    }).filter(show => show.theaters.length > 0);
    
    res.json(filteredShows);
  } catch (error) {
    console.error('Error fetching theater shows:', error);
    res.status(500).json({ 
      message: 'Error fetching theater shows', 
      error: error.message 
    });
  }
});

module.exports = router;
