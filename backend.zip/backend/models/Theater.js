const mongoose = require('mongoose');

const theaterSchema = new mongoose.Schema({
  name: {
    type: String,
    required: true,
    trim: true
  },
  location: {
    address: { type: String, required: true },
    city: { type: String, required: true },
    state: { type: String, required: true },
    zipCode: { type: String, required: true },
    coordinates: {
      latitude: Number,
      longitude: Number
    }
  },
  screens: [{
    screenNumber: { type: Number, required: true },
    capacity: { type: Number, required: true, min: 1 }
  }],
  amenities: [{
    type: String,
    enum: ['parking', 'food_court', 'wheelchair_accessible', 'air_conditioning', 'dolby_atmos']
  }],
  contact: {
    phone: String,
    email: String
  },
  isActive: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true,
  toJSON: { virtuals: true },
  toObject: { virtuals: true }
});

theaterSchema.virtual('totalCapacity').get(function() {
  return this.screens.reduce((total, screen) => total + screen.capacity, 0);
});

theaterSchema.index({ 'location.city': 1, isActive: 1 });
theaterSchema.index({ name: 1 });

module.exports = mongoose.model('Theater', theaterSchema);
